import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { 
  ArrowLeft,
  Star,
  MapPin,
  Heart,
  Share2,
  ShoppingCart
} from "lucide-react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import artisan1 from "@/assets/artisan-1.jpg";
import artisan2 from "@/assets/artisan-2.jpg";
import artisan3 from "@/assets/artisan-3.jpg";

const ArtisanStory = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [artisan, setArtisan] = useState<any>(null);

  const artisansData = [
    {
      id: "priya-sharma",
      name: "Priya Sharma",
      craft: "Traditional Pottery",
      location: "Khurja, Uttar Pradesh",
      rating: 4.8,
      image: artisan1,
      story: "Creating beautiful pottery using 300-year-old family techniques passed down through generations. My journey began as a young girl watching my grandmother shape clay with her weathered hands. Each piece I create carries the wisdom of generations, blending traditional techniques with contemporary aesthetics. The clay speaks to me, and through it, I tell stories of our rich cultural heritage.",
      specialty: "Ceramic Art",
      experience: "15 years",
      heritage: "5th generation potter",
      techniques: ["Hand-thrown pottery", "Traditional glazing", "Wood firing"],
      achievements: ["National Craft Award 2020", "Featured in Heritage Magazine", "Exhibited in 12 countries"]
    },
    {
      id: "rajesh-kumar",
      name: "Rajesh Kumar",
      craft: "Wood Carving",
      location: "Saharanpur, Uttar Pradesh", 
      rating: 4.9,
      image: artisan2,
      story: "Master craftsman specializing in intricate wooden sculptures and decorative items with traditional motifs. Wood has been my canvas for over two decades. Every grain tells a story, every cut reveals the soul of the tree. I learned this art from my father, who learned from his father. We don't just carve wood; we breathe life into it, creating pieces that will outlast us all.",
      specialty: "Heritage Craft",
      experience: "22 years",
      heritage: "4th generation woodcarver",
      techniques: ["Traditional hand carving", "Inlay work", "Natural finishing"],
      achievements: ["Master Craftsman Recognition", "UNESCO Cultural Heritage Project", "Royal Collection Contributor"]
    },
    {
      id: "meera-devi",
      name: "Meera Devi",
      craft: "Traditional Jewelry",
      location: "Jaipur, Rajasthan",
      rating: 4.7,
      image: artisan3,
      story: "Expert jeweler creating stunning pieces that blend ancient techniques with contemporary design. Gold and silver flow through my fingers like liquid poetry. Each piece of jewelry I create is not just an ornament, but a celebration of femininity, tradition, and artistry. My designs have adorned brides across generations, carrying forward the legacy of Rajasthani jewelry craftsmanship.",
      specialty: "Precious Arts",
      experience: "18 years",
      heritage: "3rd generation jeweler",
      techniques: ["Kundan setting", "Meenakari work", "Traditional filigree"],
      achievements: ["International Jewelry Designer Award", "Royal Family Commissioned Work", "Fashion Week Featured Designer"]
    }
  ];

  useEffect(() => {
    const foundArtisan = artisansData.find(a => a.id === id);
    if (foundArtisan) {
      setArtisan(foundArtisan);
    } else {
      navigate('/dashboard');
    }
  }, [id, navigate]);

  if (!artisan) {
    return <div>Loading...</div>;
  }

  const handleAddToCart = () => {
    // This will trigger the need for authentication
    alert("Please login or register to add items to cart. You'll need to connect Supabase for authentication.");
  };

  return (
    <div className="min-h-screen bg-gradient-warm">
      {/* Header */}
      <header className="bg-background/95 backdrop-blur-sm border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <motion.div 
            className="flex items-center justify-between"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Link to="/dashboard">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </motion.div>
            </Link>
            
            <div className="flex items-center space-x-2">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="ghost" size="sm">
                  <Heart className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="ghost" size="sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <img 
                src={artisan.image} 
                alt={artisan.name}
                className="w-full h-96 object-cover rounded-2xl shadow-elegant"
              />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="mb-4">
                <h1 className="text-4xl font-bold mb-2">{artisan.name}</h1>
                <p className="text-xl text-primary mb-2">{artisan.craft}</p>
                <div className="flex items-center text-muted-foreground mb-4">
                  <MapPin className="w-4 h-4 mr-1" />
                  {artisan.location}
                </div>
                <div className="flex items-center mb-6">
                  <div className="flex items-center mr-4">
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <span className="ml-1 font-semibold">{artisan.rating}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">{artisan.experience} experience</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-muted/20 p-4 rounded-lg">
                  <h3 className="font-semibold mb-1">Heritage</h3>
                  <p className="text-sm text-muted-foreground">{artisan.heritage}</p>
                </div>
                <div className="bg-muted/20 p-4 rounded-lg">
                  <h3 className="font-semibold mb-1">Specialty</h3>
                  <p className="text-sm text-muted-foreground">{artisan.specialty}</p>
                </div>
              </div>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button 
                  variant="heritage" 
                  size="lg" 
                  className="w-full"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Shop Artisan's Collection
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-12 bg-muted/20">
        <div className="container mx-auto px-4">
          <motion.div
            className="max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold mb-8 text-center">The Artisan's Story</h2>
            <div className="bg-background rounded-2xl p-8 shadow-elegant">
              <p className="text-lg leading-relaxed text-muted-foreground">
                {artisan.story}
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Techniques & Achievements */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <h3 className="text-2xl font-bold mb-6">Traditional Techniques</h3>
              <div className="space-y-3">
                {artisan.techniques.map((technique: string, index: number) => (
                  <motion.div
                    key={technique}
                    className="bg-muted/20 p-4 rounded-lg"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <p className="font-medium">{technique}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <h3 className="text-2xl font-bold mb-6">Achievements & Recognition</h3>
              <div className="space-y-3">
                {artisan.achievements.map((achievement: string, index: number) => (
                  <motion.div
                    key={achievement}
                    className="bg-primary/10 p-4 rounded-lg border-l-4 border-primary"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <p className="font-medium text-primary">{achievement}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ArtisanStory;