import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AnimatedArtisanCard from "@/components/AnimatedArtisanCard";
import { motion } from "framer-motion";
import { 
  Search,
  Filter,
  ArrowLeft,
  Grid3X3,
  List,
  SlidersHorizontal
} from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import artisan1 from "@/assets/artisan-1.jpg";
import artisan2 from "@/assets/artisan-2.jpg";
import artisan3 from "@/assets/artisan-3.jpg";

const Dashboard = () => {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchQuery, setSearchQuery] = useState("");

  const allArtisans = [
    {
      name: "Priya Sharma",
      craft: "Traditional Pottery",
      location: "Khurja, Uttar Pradesh",
      rating: 4.8,
      image: artisan1,
      story: "Creating beautiful pottery using 300-year-old family techniques passed down through generations.",
      specialty: "Ceramic Art"
    },
    {
      name: "Rajesh Kumar",
      craft: "Wood Carving",
      location: "Saharanpur, Uttar Pradesh", 
      rating: 4.9,
      image: artisan2,
      story: "Master craftsman specializing in intricate wooden sculptures and decorative items with traditional motifs.",
      specialty: "Heritage Craft"
    },
    {
      name: "Meera Devi",
      craft: "Traditional Jewelry",
      location: "Jaipur, Rajasthan",
      rating: 4.7,
      image: artisan3,
      story: "Expert jeweler creating stunning pieces that blend ancient techniques with contemporary design.",
      specialty: "Precious Arts"
    },
    {
      name: "Arjun Patel",
      craft: "Textile Weaving",
      location: "Bhuj, Gujarat",
      rating: 4.6,
      image: artisan1,
      story: "Traditional weaver specializing in intricate patterns and natural dyes passed down through generations.",
      specialty: "Textile Arts"
    },
    {
      name: "Kavita Singh",
      craft: "Metal Craft",
      location: "Moradabad, Uttar Pradesh",
      rating: 4.8,
      image: artisan2,
      story: "Skilled metalworker creating beautiful brass and copper items with traditional engravings.",
      specialty: "Metal Arts"
    },
    {
      name: "Ravi Artisan",
      craft: "Stone Carving", 
      location: "Makrana, Rajasthan",
      rating: 4.9,
      image: artisan3,
      story: "Master stone carver working with marble and sandstone to create architectural marvels.",
      specialty: "Stone Craft"
    }
  ];

  const filteredArtisans = allArtisans.filter(artisan =>
    artisan.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    artisan.craft.toLowerCase().includes(searchQuery.toLowerCase()) ||
    artisan.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-warm">
      {/* Header */}
      <header className="bg-background/95 backdrop-blur-sm border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-6">
          <motion.div 
            className="flex items-center justify-between"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center space-x-4">
              <Link to="/">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button variant="ghost" size="sm">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Home
                  </Button>
                </motion.div>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">Artisan Dashboard</h1>
                <p className="text-muted-foreground">Discover all talented craftspeople</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="w-4 h-4" />
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Filters and Search */}
      <section className="py-8 bg-muted/20">
        <div className="container mx-auto px-4">
          <motion.div 
            className="flex flex-col md:flex-row gap-4 items-center justify-between"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search artisans, crafts, or locations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="outline" size="sm">
                  <SlidersHorizontal className="w-4 h-4 mr-2" />
                  Filters
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Sort by Rating
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Results */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <motion.div 
            className="mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <p className="text-muted-foreground">
              Showing {filteredArtisans.length} of {allArtisans.length} artisans
            </p>
          </motion.div>

          <motion.div 
            className={`grid gap-6 ${
              viewMode === "grid" 
                ? "md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" 
                : "grid-cols-1 max-w-4xl mx-auto"
            }`}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            {filteredArtisans.map((artisan, index) => (
              <AnimatedArtisanCard 
                key={`${artisan.name}-${index}`} 
                {...artisan} 
                index={index}
              />
            ))}
          </motion.div>

          {filteredArtisans.length === 0 && (
            <motion.div 
              className="text-center py-12"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
            >
              <p className="text-muted-foreground text-lg mb-4">
                No artisans found matching your search.
              </p>
              <Button 
                variant="outline" 
                onClick={() => setSearchQuery("")}
              >
                Clear Search
              </Button>
            </motion.div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;