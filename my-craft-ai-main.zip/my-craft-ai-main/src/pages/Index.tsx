import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import AnimatedNavigation from "@/components/AnimatedNavigation";
import AnimatedArtisanCard from "@/components/AnimatedArtisanCard";
import StoryGenerator from "@/components/StoryGenerator";
import AnimatedHero from "@/components/AnimatedHero";
import AnimatedFeatures from "@/components/AnimatedFeatures";
import { motion } from "framer-motion";
import { 
  Lightbulb,
  Users,
  Heart,
  ArrowRight,
  Sparkles
} from "lucide-react";
import artisan1 from "@/assets/artisan-1.jpg";
import artisan2 from "@/assets/artisan-2.jpg";
import artisan3 from "@/assets/artisan-3.jpg";

const Index = () => {
  const featuredArtisans = [
    {
      name: "Priya Sharma",
      craft: "Traditional Pottery",
      location: "Khurja, Uttar Pradesh",
      rating: 4.8,
      image: artisan1,
      story: "Creating beautiful pottery using 300-year-old family techniques passed down through generations.",
      specialty: "Ceramic Art"
    },
    {
      name: "Rajesh Kumar",
      craft: "Wood Carving",
      location: "Saharanpur, Uttar Pradesh", 
      rating: 4.9,
      image: artisan2,
      story: "Master craftsman specializing in intricate wooden sculptures and decorative items with traditional motifs.",
      specialty: "Heritage Craft"
    },
    {
      name: "Meera Devi",
      craft: "Traditional Jewelry",
      location: "Jaipur, Rajasthan",
      rating: 4.7,
      image: artisan3,
      story: "Expert jeweler creating stunning pieces that blend ancient techniques with contemporary design.",
      specialty: "Precious Arts"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-warm">
      <AnimatedNavigation />
      
      <AnimatedHero />
      <AnimatedFeatures />

      {/* Featured Artisans */}
      <section id="artisans" className="py-16">
        <div className="container mx-auto px-4">
          <motion.div 
            className="flex items-center justify-between mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Artisans</h2>
              <p className="text-muted-foreground">
                Discover talented craftspeople preserving traditional arts
              </p>
            </div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link to="/dashboard">
                <Button variant="outline">
                  View All
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </motion.div>
          </motion.div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredArtisans.map((artisan, index) => (
              <AnimatedArtisanCard key={index} {...artisan} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* AI Story Generator Section */}
      <section id="ai-tools" className="py-16 bg-muted/20">
        <div className="container mx-auto px-4">
          <StoryGenerator />
        </div>
      </section>

      {/* CTA Section */}
      <motion.section 
        className="py-16 bg-gradient-royal relative overflow-hidden"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
      >
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-3xl mx-auto">
            <motion.div 
              className="w-16 h-16 bg-primary-foreground/10 rounded-2xl flex items-center justify-center mx-auto mb-6"
              animate={{ 
                y: [0, -10, 0],
                rotate: [0, 5, 0]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Lightbulb className="w-8 h-8 text-primary-foreground" />
            </motion.div>
            
            <motion.h2 
              className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-4"
              initial={{ scale: 0.9, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6 }}
            >
              Ready to Transform Your Craft Business?
            </motion.h2>
            
            <motion.p 
              className="text-xl text-primary-foreground/90 mb-8"
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Join hundreds of artisans who are already using AI to tell their stories, 
              reach new customers, and preserve their cultural heritage.
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center"
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="secondary" size="lg" className="group">
                  <Users className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                  Join as Artisan
                </Button>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="outline" size="lg" className="border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10">
                  <Heart className="w-5 h-5 mr-2" />
                  Support Artisans
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Footer */}
      <footer className="py-12 bg-foreground/5 border-t border-border">
        <div className="container mx-auto px-4">
          <motion.div 
            className="grid md:grid-cols-4 gap-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold">Kala Setu</h3>
              </div>
              <p className="text-muted-foreground max-w-md">
                Empowering artisans with AI-driven tools to preserve cultural heritage 
                and reach global audiences in the digital age.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <div className="space-y-2 text-muted-foreground">
                <div>AI Story Generator</div>
                <div>Marketing Tools</div>
                <div>Artisan Dashboard</div>
                <div>Analytics</div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Community</h4>
              <div className="space-y-2 text-muted-foreground">
                <div>Featured Artisans</div>
                <div>Success Stories</div>
                <div>Cultural Heritage</div>
                <div>Support Center</div>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="border-t border-border mt-8 pt-8 text-center text-muted-foreground"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <p>© 2024 Kala Setu. Preserving heritage, empowering artisans.</p>
          </motion.div>
        </div>
      </footer>
    </div>
  );
};

export default Index;